const BASE = 'https://pokeapi.co/api/v2'; // URL base de la API de Pokémon

const TYPE_COLORS = { // Colores para cada tipo de Pokémon
  normal:'#A8A878', fire:'#F08030', water:'#6890F0', electric:'#F8D030',
  grass:'#78C850', ice:'#98D8D8', fighting:'#C03028', poison:'#A040A0',
  ground:'#E0C068', flying:'#A890F0', psychic:'#F85888', bug:'#A8B820',
  rock:'#B8A038', ghost:'#705898', dragon:'#7038F8', dark:'#705848',
  steel:'#B8B8D0', fairy:'#EE99AC'
};

let currentPage = 'catalog'; // Página actual (catalog, search, moves, items, team, detail)
let prevPage = 'catalog';
let catalogOffset = 0;
let catalogLimit = 20;
let catalogTotal = 0;
let activeFilter = '';
let allCatalogUrls = [];

let user = null;//
let team = JSON.parse(localStorage.getItem('poketeam') || '[]');// Equipo del usuario, cargado desde localStorage

function showPage(name) { // Función para mostrar la página correspondiente
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  const btns = document.querySelectorAll('.nav-btn');
  btns.forEach(b => { if (b.textContent.toLowerCase().includes(name === 'catalog' ? 'catálogo' : name === 'search' ? 'buscar' : name === 'moves' ? 'movim' : name === 'items' ? 'ítem' : 'equipo')) b.classList.add('active'); });
  prevPage = currentPage;
  currentPage = name;
  if (name === 'team') renderTeam();
}

function goBack() { showPage(prevPage === 'detail' ? 'catalog' : prevPage); } // Función para volver a la página anterior (no vuelve a 'detail' para evitar confusión)

function typeBadge(t) {
  return `<span class="type-badge" style="background:${TYPE_COLORS[t]||'#888'}">${t}</span>`;
}

function spriteUrl(id) { // Función para obtener la URL del sprite oficial de un Pokémon por su ID
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}

async function loadCatalog() { // Función para cargar el catálogo completo de Pokémon
  document.getElementById('catalogGrid').innerHTML = '<div class="loading">Cargando pokédex...</div>';
  try {
    const res = await fetch(`${BASE}/pokemon?limit=10000&offset=0`);
    const data = await res.json();
    catalogTotal = data.count;
    allCatalogUrls = data.results;
    renderCatalogPage(0);
  } catch(e) {
    document.getElementById('catalogGrid').innerHTML = '<div class="error-msg">Error al cargar el catálogo.</div>';
  }
}

async function applyFilter() { // Función para aplicar el filtro de tipo seleccionado
  activeFilter = document.getElementById('typeFilter').value;
  catalogOffset = 0;
  if (!activeFilter) {
    renderCatalogPage(0);
    return;
  }
  document.getElementById('catalogGrid').innerHTML = '<div class="loading">Filtrando...</div>';
  const res = await fetch(`${BASE}/type/${activeFilter}`);
  const data = await res.json();
  allCatalogUrls = data.pokemon.map(p => ({ name: p.pokemon.name, url: p.pokemon.url }));
  catalogTotal = allCatalogUrls.length;
  renderCatalogPage(0);
}

function changePerPage() { // Función para cambiar la cantidad de Pokémon mostrados por página
  catalogLimit = parseInt(document.getElementById('perPage').value);
  catalogOffset = 0;
  renderCatalogPage(0);
}

function renderCatalogPage(offset) { // Función para renderizar una página del catálogo según el offset y el límite establecidos
  catalogOffset = offset;
  const slice = allCatalogUrls.slice(offset, offset + catalogLimit);
  const grid = document.getElementById('catalogGrid');
  grid.innerHTML = '';

  slice.forEach(p => { // Extrae el ID del Pokémon de su URL para mostrar su sprite y número
    const id = parseInt(p.url.split('/').filter(Boolean).pop());
    if (id > 10000) return;
    const card = document.createElement('div');
    card.className = 'pokemon-card';
    card.innerHTML = `
      <img src="${spriteUrl(id)}" alt="${p.name}" loading="lazy" onerror="this.src='https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png'">
      <div class="num">#${String(id).padStart(3,'0')}</div>
      <h3>${p.name}</h3>
    `;
    card.onclick = () => openDetail(p.name);
    grid.appendChild(card);
  });

  renderPagination();
}

function renderPagination() { // Función para renderizar los botones de paginación según el número total de Pokémon y el límite por página
  const total = Math.ceil(allCatalogUrls.length / catalogLimit);
  const cur = Math.floor(catalogOffset / catalogLimit);
  const pag = document.getElementById('catalogPagination');
  pag.innerHTML = '';

  const addBtn = (label, offset, isCur) => { // Función auxiliar para crear un botón de página
    const b = document.createElement('button');
    b.className = 'page-btn' + (isCur ? ' active' : '');
    b.textContent = label;
    b.onclick = () => renderCatalogPage(offset);
    pag.appendChild(b);
  };

  if (cur > 0) addBtn('‹ Ant', (cur - 1) * catalogLimit, false);

  const start = Math.max(0, cur - 2);
  const end = Math.min(total - 1, cur + 2);
  for (let i = start; i <= end; i++) addBtn(i + 1, i * catalogLimit, i === cur);

  if (cur < total - 1) addBtn('Sig ›', (cur + 1) * catalogLimit, false);
}

async function searchPokemon() { // Función para buscar un Pokémon por nombre o número ingresado en el formulario de búsqueda
  const q = document.getElementById('searchInput').value.toLowerCase().trim().replace('#','');
  if (!q) return;
  document.getElementById('searchResult').innerHTML = '<div class="loading">Buscando...</div>';
  try {
    const res = await fetch(`${BASE}/pokemon/${q}`);
    if (!res.ok) throw new Error();
    const data = await res.json();
    showPage('search');
    renderSearchCard(data, 'searchResult');
  } catch {
    document.getElementById('searchResult').innerHTML = '<div class="error-msg">Pokémon no encontrado.</div>';
  }
}

async function randomPokemon() { // Función para mostrar un Pokémon aleatorio al hacer clic en el botón "Random"
  const id = Math.floor(Math.random() * 898) + 1;
  document.getElementById('searchInput').value = id;
  await searchPokemon();
}

function renderSearchCard(data, containerId) { // Función para renderizar la tarjeta de un Pokémon con su información básica (usada tanto en búsqueda como en resultados relacionados)
  const tipos = data.types.map(t => typeBadge(t.type.name)).join('');
  const hp = data.stats.find(s => s.stat.name === 'hp').base_stat;
  const atk = data.stats.find(s => s.stat.name === 'attack').base_stat;
  const def = data.stats.find(s => s.stat.name === 'defense').base_stat;
  const spd = data.stats.find(s => s.stat.name === 'speed').base_stat;

  document.getElementById(containerId).innerHTML = `
    <div class="section-card" style="max-width:440px; margin:0 auto; cursor:pointer;" onclick="openDetail('${data.name}')">
      <img src="${spriteUrl(data.id)}" style="width:140px; display:block; margin:0 auto 12px;">
      <h2 style="text-align:center; text-transform:capitalize; margin-bottom:4px;">${data.name}</h2>
      <p style="text-align:center; color:#888; margin-bottom:12px;">#${String(data.id).padStart(3,'0')}</p>
      <div class="types" style="margin-bottom:16px;">${tipos}</div>
      <div class="stats-grid">
        <div class="stat-box"><div class="label">HP</div><div class="val">${hp}</div></div>
        <div class="stat-box"><div class="label">Ataque</div><div class="val">${atk}</div></div>
        <div class="stat-box"><div class="label">Defensa</div><div class="val">${def}</div></div>
        <div class="stat-box"><div class="label">Velocidad</div><div class="val">${spd}</div></div>
      </div>
      <p style="text-align:center; margin-top:12px; color:#888; font-size:13px;">Clic para ver detalles completos</p>
    </div>
  `;
}

async function openDetail(name) { // Función para mostrar la página de detalles de un Pokémon específico al hacer clic en su tarjeta
  prevPage = currentPage;
  showPage('detail');
  document.getElementById('detailContent').innerHTML = '<div class="loading">Cargando detalles...</div>';
  try {
    const [pokeRes, speciesRes] = await Promise.all([
      fetch(`${BASE}/pokemon/${name}`),
      fetch(`${BASE}/pokemon-species/${name}`)
    ]);
    const pokemon = await pokeRes.json();
    const species = await speciesRes.json();

    const moves = await loadMoves(pokemon.moves.slice(0, 4));
    renderDetail(pokemon, species, moves);
  } catch(e) {
    document.getElementById('detailContent').innerHTML = '<div class="error-msg">Error al cargar detalles.</div>';
  }
}

async function loadMoves(moveList) { // Función para cargar los detalles de los movimientos de un Pokémon (limitado a los primeros 4 para no saturar la página)
  const results = [];
  for (const m of moveList) {
    try {
      const r = await fetch(m.move.url);
      results.push(await r.json());
    } catch {}
  }
  return results;
}

async function renderDetail(pokemon, species, moves) { // Función para renderizar la página de detalles de un Pokémon con su información completa, incluyendo tipos, estadísticas, descripción y movimientos
  const tipos = pokemon.types.map(t => typeBadge(t.type.name)).join('');
  const stats = ['hp','attack','defense','special-attack','special-defense','speed'];
  const statLabels = { hp:'HP', attack:'Ataque', defense:'Defensa', 'special-attack':'Atq. Esp.', 'special-defense':'Def. Esp.', speed:'Velocidad' };

  let desc = 'Sin descripción.';
  const es = species.flavor_text_entries.find(e => e.language.name === 'es');
  if (es) {
    desc = es.flavor_text.replace(/\n/g, ' ');
  } else {
    const fr = species.flavor_text_entries.find(e => e.language.name === 'fr');
    if (fr) {
      desc = await corregirIdioma(fr.flavor_text.replace(/\n/g, ' '));
    }
  }

  const statsHtml = stats.map(s => { // Para cada estadística, encuentra su valor base y calcula un porcentaje para mostrar una barra visual
    const found = pokemon.stats.find(x => x.stat.name === s);
    const val = found ? found.base_stat : 0;
    const pct = Math.min(100, Math.round(val / 255 * 100));
    return `
      <div class="stat-bar-row">
        <span class="slabel">${statLabels[s]}</span>
        <span class="sval">${val}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
      </div>`;
  }).join('');

  const movesHtml = (await Promise.all(moves.map(async m => { // Para cada movimiento, crea una tarjeta con su información traducida al español
    const effEntry = m.effect_entries ? m.effect_entries.find(e => e.language.name === 'en') || m.effect_entries[0] : null;
    const eff = effEntry ? await corregirIdioma(effEntry.short_effect.replace(/\$effect_chance/g, m.effect_chance || '?')) : '';
    return `
      <div class="move-item">
        <h4>${m.name.replace(/-/g,' ')}</h4>
        <div class="move-meta">
          ${m.power ? `<span>Potencia: ${m.power}</span>` : ''}
          ${m.accuracy ? `<span>Precisión: ${m.accuracy}%</span>` : ''}
          ${m.pp ? `<span>PP: ${m.pp}</span>` : ''}
          <span style="background:${TYPE_COLORS[m.type?.name]||'#555'}">${m.type?.name||''}</span>
          ${m.damage_class ? `<span>${m.damage_class.name}</span>` : ''}
        </div>
        ${eff ? `<p>${eff}</p>` : ''}
      </div>`;
  }))).join('');

  const inTeam = team.some(t => t.name === pokemon.name); // Verifica si el Pokémon ya está en el equipo del usuario para mostrar el botón correcto (agregar o quitar)
  const teamBtn = user
    ? `<button class="btn ${inTeam ? 'btn-danger' : 'btn-secondary'} btn-sm" onclick="${inTeam ? `removeFromTeam('${pokemon.name}')` : `addToTeam(${pokemon.id},'${pokemon.name}')`}">
        ${inTeam ? '✕ Quitar del equipo' : '+ Agregar al equipo'}
      </button>`
    : `<button class="btn btn-outline btn-sm" onclick="openLogin()">Inicia sesión para agregar al equipo</button>`;

  document.getElementById('detailContent').innerHTML = `
    <div class="detail-header">
      <div class="detail-img-box">
        <img src="${spriteUrl(pokemon.id)}" alt="${pokemon.name}">
        <div class="types" style="margin-top:12px;">${tipos}</div>
        <div style="margin-top:14px;">${teamBtn}</div>
      </div>
      <div class="detail-info">
        <div class="num">#${String(pokemon.id).padStart(3,'0')} · ${species.generation?.name?.replace('generation-','Gen ').toUpperCase() || ''}</div>
        <h2>${pokemon.name}</h2>
        <div class="desc-box">${desc}</div>
        <div class="stats-grid" style="margin-top:16px;">
          <div class="stat-box"><div class="label">Altura</div><div class="val">${pokemon.height/10}m</div></div>
          <div class="stat-box"><div class="label">Peso</div><div class="val">${pokemon.weight/10}kg</div></div>
          <div class="stat-box"><div class="label">Exp. Base</div><div class="val">${pokemon.base_experience}</div></div>
          <div class="stat-box"><div class="label">Capturas</div><div class="val">${species.capture_rate}</div></div>
        </div>
        <div style="margin-top:16px;">${statsHtml}</div>
      </div>
    </div>
    <div class="section-card">
      <h3>Movimientos (primeros 4)</h3>
      ${movesHtml || '<p style="color:#888">Sin movimientos disponibles.</p>'}
    </div>
  `;
}

async function searchMove() { //  Función para buscar un movimiento por nombre ingresado en el formulario de búsqueda de movimientos
  const q = document.getElementById('moveInput').value.toLowerCase().trim().replace(/ /g,'-');
  if (!q) return;
  document.getElementById('moveResult').innerHTML = '<div class="loading">Buscando movimiento...</div>';
  try {
    const res = await fetch(`${BASE}/move/${q}`);
    if (!res.ok) throw new Error();
    const m = await res.json();
    const effEntry = m.effect_entries ? m.effect_entries.find(e => e.language.name === 'en') || m.effect_entries[0] : null;
    const eff = effEntry ? await corregirIdioma(effEntry.effect.replace(/\$effect_chance/g, m.effect_chance || '?')) : 'Sin descripción.';
    document.getElementById('moveResult').innerHTML = `
      <div class="section-card" style="max-width:500px;">
        <h3>${m.name.replace(/-/g,' ')}</h3>
        <div class="move-meta" style="margin-bottom:12px;">
          ${m.power ? `<span>Potencia: ${m.power}</span>` : '<span>Potencia: —</span>'}
          ${m.accuracy ? `<span>Precisión: ${m.accuracy}%</span>` : '<span>Precisión: —</span>'}
          <span>PP: ${m.pp}</span>
          <span style="background:${TYPE_COLORS[m.type?.name]||'#555'}; color:#fff; padding:3px 10px; border-radius:20px;">${m.type?.name||''}</span>
          <span>${m.damage_class?.name||''}</span>
        </div>
        <p style="font-size:13px; color:#bbb; line-height:1.6;">${eff}</p>
      </div>
    `;
  } catch {
    document.getElementById('moveResult').innerHTML = '<div class="error-msg">Movimiento no encontrado. Escribe el nombre en inglés (ej: flamethrower)</div>';
  }
}

async function searchItem() { // Función para buscar un ítem por nombre ingresado en el formulario de búsqueda de ítems
  const q = document.getElementById('itemInput').value.toLowerCase().trim().replace(/ /g,'-');
  if (!q) return;
  document.getElementById('itemResult').innerHTML = '<div class="loading">Buscando ítem...</div>';
  try {
    const res = await fetch(`${BASE}/item/${q}`);
    if (!res.ok) throw new Error();
    const item = await res.json();
    const eff = item.effect_entries && item.effect_entries[0] ? item.effect_entries[0].effect : 'Sin descripción.';
    document.getElementById('itemResult').innerHTML = `
      <div class="section-card" style="max-width:460px;">
        <div style="display:flex; gap:16px; align-items:center; margin-bottom:12px;">
          ${item.sprites?.default ? `<img src="${item.sprites.default}" style="width:48px; image-rendering:pixelated;">` : ''}
          <div>
            <h3 style="font-size:18px; text-transform:capitalize; margin-bottom:4px;">${item.name.replace(/-/g,'')}</h3>
            <span style="font-size:12px; color:#888;">Costo: ${item.cost} ₽</span>
          </div>
        </div>
        <p style="font-size:13px; color:#bbb; line-height:1.6;">${eff}</p>
      </div>
    `;
  } catch {
    document.getElementById('itemResult').innerHTML = '<div class="error-msg">Ítem no encontrado. Escribe el nombre en inglés (ej: potion, master-ball)</div>';
  }
}

async function loadItemCatalog() { // Función para cargar un catálogo de ítems (limitado a los primeros 40 para no saturar la página)
  document.getElementById('itemResult').innerHTML = '<div class="loading">Cargando ítems...</div>';
  try {
    const res = await fetch(`${BASE}/item?limit=40&offset=0`);
    const data = await res.json();
    const details = await Promise.all(data.results.slice(0,20).map(i => fetch(i.url).then(r=>r.json())));
    document.getElementById('itemResult').innerHTML = `
      <div class="item-grid" style="margin-top:8px;">
        ${details.map(item => `
          <div class="item-card">
            ${item.sprites?.default ? `<img src="${item.sprites.default}">` : '<div style="width:36px;height:36px;background:#1a1a2e;border-radius:6px;"></div>'}
            <div>
              <div class="iname">${item.name.replace(/-/g,' ')}</div>
              <div class="icost">${item.cost} ₽</div>
            </div>
          </div>
        `).join('')}
      </div>`;
  } catch {
    document.getElementById('itemResult').innerHTML = '<div class="error-msg">Error al cargar ítems.</div>';
  }
}

function renderTeam() { // Función para renderizar el equipo del usuario en la página de equipo, mostrando los Pokémon agregados o espacios vacíos si no hay 6
  const grid = document.getElementById('teamGrid');
  grid.innerHTML = '';
  for (let i = 0; i < 6; i++) {
    const slot = document.createElement('div');
    slot.className = 'team-slot' + (team[i] ? ' filled' : '');
    if (team[i]) {
      slot.innerHTML = `
        <button class="remove-btn" onclick="removeFromTeam('${team[i].name}')">✕</button>
        <img src="${spriteUrl(team[i].id)}" alt="${team[i].name}">
        <div class="tname">${team[i].name}</div>
      `;
    } else {
      slot.innerHTML = `<span style="color:#555; font-size:12px;">Vacío</span>`;
    }
    grid.appendChild(slot);
  }
}

async function teamSearch() { // Función para buscar un Pokémon y agregarlo al equipo desde la página de equipo, similar a la función de búsqueda general pero con enfoque en agregar al equipo
  if (!user) { openLogin(); return; }
  const q = document.getElementById('teamSearchInput').value.toLowerCase().trim().replace('#','');
  if (!q) return;
  try {
    const res = await fetch(`${BASE}/pokemon/${q}`);
    if (!res.ok) throw new Error();
    const data = await res.json();
    document.getElementById('teamSearchResult').innerHTML = `
      <div style="display:flex; align-items:center; gap:12px; margin-top:12px; background:#0f3460; border-radius:10px; padding:12px;">
        <img src="${spriteUrl(data.id)}" style="width:60px;">
        <div>
          <div style="font-size:15px; font-weight:600; text-transform:capitalize;">${data.name}</div>
          <div style="font-size:12px; color:#888; margin-bottom:8px;">#${String(data.id).padStart(3,'0')}</div>
          <button class="btn btn-primary btn-sm" onclick="addToTeam(${data.id},'${data.name}')">+ Agregar al equipo</button>
        </div>
      </div>
    `;
  } catch {
    document.getElementById('teamSearchResult').innerHTML = '<div class="error-msg" style="padding:12px;">Pokémon no encontrado.</div>';
  }
}

function addToTeam(id, name) { // Función para agregar un Pokémon al equipo del usuario
  if (!user) { openLogin(); return; }
  if (team.length >= 6) { alert('Tu equipo ya tiene 6 Pokémon.'); return; }
  if (team.some(t => t.name === name)) { alert('Este Pokémon ya está en tu equipo.'); return; }
  team.push({ id, name });
  saveTeam();
  renderTeam();
  if (currentPage === 'detail') {
    const btn = document.querySelector('#detailContent button');
    if (btn && btn.textContent.includes('Agregar')) {
      btn.textContent = '✕ Quitar del equipo';
      btn.className = 'btn btn-danger btn-sm';
      btn.onclick = () => removeFromTeam(name);
    }
  }
}

function removeFromTeam(name) { // Función para quitar un Pokémon del equipo del usuario
  team = team.filter(t => t.name !== name);
  saveTeam();
  renderTeam();
}

function clearTeam() { // Función para limpiar todo el equipo del usuario, eliminando los 6 espacios y guardando el cambio en localStorage
  if (!confirm('¿Limpiar todo el equipo?')) return;
  team = [];
  saveTeam();
  renderTeam();
}

function saveTeam() { localStorage.setItem('poketeam', JSON.stringify(team)); }

const USERS = { // Usuarios registrados para iniciar sesión (clave: usuario, valor: contraseña)
  misty: 'togepi', 
  brock: 'onix',
  TUNGTUNG: 'SAHUR' 
};

function openLogin() { document.getElementById('loginModal').classList.add('open'); }
function closeLogin() { document.getElementById('loginModal').classList.remove('open'); document.getElementById('loginError').textContent = ''; }

function doLogin() { // Función para manejar el inicio de sesión del usuario, verificando las credenciales ingresadas contra el objeto USERS y actualizando la interfaz en consecuencia
  const u = document.getElementById('loginUser').value.trim();
  const p = document.getElementById('loginPass').value;
  if (USERS[u] && USERS[u] === p) {
    user = u;
    closeLogin();
    document.getElementById('navUser').innerHTML = `
      <div class="user-avatar" title="${u}">${u[0].toUpperCase()}</div>
      <button class="btn btn-outline btn-sm" onclick="doLogout()">Salir</button>
    `;
    showPage('team');
  } else {
    document.getElementById('loginError').textContent = 'Usuario o contraseña incorrectos.';
  }
}

function doLogout() {// Función para manejar el cierre de sesión del usuario, limpiando la variable user y actualizando la interfaz para mostrar el botón de iniciar sesión nuevamente
  user = null;
  document.getElementById('navUser').innerHTML = `<button class="btn btn-outline btn-sm" onclick="openLogin()">Iniciar Sesión</button>`;
}

document.getElementById('loginModal').addEventListener('click', function(e) {
  if (e.target === this) closeLogin();
});

function init() {

}

async function corregirIdioma(texto, idiomaOrigen = 'en', idiomaDestino = 'es') { // Función para traducir un texto al español usando la API de MyMemory
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(texto)}&langpair=${idiomaOrigen}|${idiomaDestino}`;
    const respuesta = await fetch(url);
    const datos = await respuesta.json();
    if (datos.responseData && datos.responseData.translatedText) {
      return datos.responseData.translatedText;
    } else {
      throw new Error('No se pudo traducir el texto');
    }
  } catch (error) {
    console.error('Error en la traducción:', error);
    return texto; // Retorna el texto original si hay error
  }
}

const GENERATION_RANGES = {
  1: { min: 1,   max: 151 },
  2: { min: 152, max: 251 },
  3: { min: 252, max: 386 },
  4: { min: 387, max: 493 },
  5: { min: 494, max: 649 },
  6: { min: 650, max: 721 },
  7: { min: 722, max: 809 },
  8: { min: 810, max: 905 },
};

async function applyFilter() { // funcion para buscar por tipo y generación, combinando ambos filtros si se seleccionan, recargando el catálogo completo y luego filtrando según los criterios seleccionados antes de renderizar la página del catálogo
  const typeValue = document.getElementById('typeFilter').value;
  const genValue  = document.getElementById('generationFilter').value;

  document.getElementById('catalogGrid').innerHTML = '<div class="loading">Filtrando...</div>';

  const res = await fetch(`${BASE}/pokemon?limit=10000&offset=0`);
  const data = await res.json();
  allCatalogUrls = data.results;

  if (genValue) {
    const { min, max } = GENERATION_RANGES[genValue];
    allCatalogUrls = allCatalogUrls.filter(p => {
      const id = parseInt(p.url.split('/').filter(Boolean).pop());
      return id >= min && id <= max;
    });
  }

  if (typeValue) {
    const typeRes = await fetch(`${BASE}/type/${typeValue}`);
    const typeData = await typeRes.json();
    const typeUrls = new Set(typeData.pokemon.map(p => p.pokemon.url));
    allCatalogUrls = allCatalogUrls.filter(p => typeUrls.has(p.url));
  }

  catalogTotal = allCatalogUrls.length;
  renderCatalogPage(0);
}

loadCatalog();
renderTeam(); // Carga el catálogo al iniciar la página y muestra el equipo guardado en localStorage